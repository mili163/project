import React, { useState } from "react";
import { Provider } from "react-redux";
import { store } from "./store";
import { ImportPage } from "./components/ImportPage";
import { ClassroomsPage } from "./components/ClassroomsPage";
import { SortPage } from "./components/SortPage";
import "./styles.css";

type Tab = "import" | "classrooms" | "sort";

const App: React.FC = () => {
  const [tab, setTab] = useState<Tab>("import");

  return (
    <Provider store={store}>
      <div dir="rtl" className="app">
        <nav className="navbar">
          <span className="nav-brand">🏫 מערכת שיבוץ תלמידים</span>
          <div className="nav-tabs">
            {(["import", "classrooms", "sort"] as Tab[]).map((t) => (
              <button
                key={t}
                className={`nav-tab ${tab === t ? "active" : ""}`}
                onClick={() => setTab(t)}
              >
                {t === "import" && "ייבוא תלמידים"}
                {t === "classrooms" && "ניהול כיתות"}
                {t === "sort" && "מיון ושיבוץ"}
              </button>
            ))}
          </div>
        </nav>
        <main className="main-content">
          {tab === "import" && <ImportPage />}
          {tab === "classrooms" && <ClassroomsPage />}
          {tab === "sort" && <SortPage />}
        </main>
      </div>
    </Provider>
  );
};

export default App;
