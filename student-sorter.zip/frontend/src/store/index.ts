import { configureStore } from "@reduxjs/toolkit";
import { useDispatch, useSelector, TypedUseSelectorHook } from "react-redux";
import studentsReducer from "./studentsSlice";
import classroomsReducer from "./classroomsSlice";
import sortReducer from "./sortSlice";

export const store = configureStore({
  reducer: {
    students: studentsReducer,
    classrooms: classroomsReducer,
    sort: sortReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

// Typed hooks — use these everywhere instead of plain useDispatch/useSelector
export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
