import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { api } from "../../services/api";
import { Student } from "../../types";

interface StudentsState {
  items: Student[];
  loading: boolean;
  error: string | null;
}

const initialState: StudentsState = {
  items: [],
  loading: false,
  error: null,
};

export const fetchStudents = createAsyncThunk(
  "students/fetch",
  () => api.getStudents()
);

export const importStudents = createAsyncThunk(
  "students/import",
  (file: File) => api.importStudents(file)
);

export const clearStudents = createAsyncThunk("students/clear", async () => {
  await api.clearStudents();
});

const studentsSlice = createSlice({
  name: "students",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchStudents.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(fetchStudents.fulfilled, (s, a) => { s.loading = false; s.items = a.payload; })
      .addCase(fetchStudents.rejected, (s, a) => { s.loading = false; s.error = a.error.message ?? "Error"; })

      .addCase(importStudents.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(importStudents.fulfilled, (s, a) => { s.loading = false; s.items = a.payload; })
      .addCase(importStudents.rejected, (s, a) => { s.loading = false; s.error = a.error.message ?? "Error"; })

      .addCase(clearStudents.fulfilled, (s) => { s.items = []; });
  },
});

export default studentsSlice.reducer;
