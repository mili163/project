import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { api } from "../../services/api";
import { SortResult } from "../../types";

interface SortState {
  result: SortResult | null;
  loading: boolean;
  error: string | null;
}

const initialState: SortState = { result: null, loading: false, error: null };

export const runSort = createAsyncThunk("sort/run", () => api.runSort());
export const fetchLastSort = createAsyncThunk("sort/fetchLast", () => api.getLastSort());

const sortSlice = createSlice({
  name: "sort",
  initialState,
  reducers: {
    clearSort: (s) => { s.result = null; },
  },
  extraReducers: (builder) => {
    builder
      .addCase(runSort.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(runSort.fulfilled, (s, a) => { s.loading = false; s.result = a.payload; })
      .addCase(runSort.rejected, (s, a) => { s.loading = false; s.error = a.error.message ?? "Error"; })
      .addCase(fetchLastSort.fulfilled, (s, a) => { s.result = a.payload; });
  },
});

export const { clearSort } = sortSlice.actions;
export default sortSlice.reducer;
