import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { api } from "../../services/api";
import { Classroom } from "../../types";

interface ClassroomsState {
  items: Classroom[];
  loading: boolean;
  error: string | null;
}

const initialState: ClassroomsState = { items: [], loading: false, error: null };

export const fetchClassrooms = createAsyncThunk(
  "classrooms/fetch",
  () => api.getClassrooms()
);

export const createClassroom = createAsyncThunk(
  "classrooms/create",
  (dto: Omit<Classroom, "id">) => api.createClassroom(dto)
);

export const updateClassroom = createAsyncThunk(
  "classrooms/update",
  ({ id, dto }: { id: number; dto: Omit<Classroom, "id"> }) =>
    api.updateClassroom(id, dto)
);

export const deleteClassroom = createAsyncThunk(
  "classrooms/delete",
  async (id: number) => { await api.deleteClassroom(id); return id; }
);

const classroomsSlice = createSlice({
  name: "classrooms",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchClassrooms.pending, (s) => { s.loading = true; })
      .addCase(fetchClassrooms.fulfilled, (s, a) => { s.loading = false; s.items = a.payload; })
      .addCase(fetchClassrooms.rejected, (s, a) => { s.loading = false; s.error = a.error.message ?? "Error"; })

      .addCase(createClassroom.fulfilled, (s, a) => { s.items.push(a.payload); })
      .addCase(updateClassroom.fulfilled, (s, a) => {
        const idx = s.items.findIndex((c) => c.id === a.payload.id);
        if (idx !== -1) s.items[idx] = a.payload;
      })
      .addCase(deleteClassroom.fulfilled, (s, a) => {
        s.items = s.items.filter((c) => c.id !== a.payload);
      });
  },
});

export default classroomsSlice.reducer;
