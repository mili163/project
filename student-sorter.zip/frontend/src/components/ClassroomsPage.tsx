import React, { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../store";
import {
  fetchClassrooms,
  createClassroom,
  updateClassroom,
  deleteClassroom,
} from "../store/classroomsSlice";
import {
  Classroom,
  DisabilityType,
  GradeLevel,
  DISABILITY_LABELS,
  GRADE_LABELS,
} from "../types";

const ALL_DISABILITIES = Object.values(DisabilityType).filter(
  (d) => d !== DisabilityType.None
) as DisabilityType[];
const ALL_GRADES = [
  GradeLevel.Alef, GradeLevel.Bet, GradeLevel.Gimel,
  GradeLevel.Dalet, GradeLevel.He, GradeLevel.Vav,
];

const emptyForm = (): Omit<Classroom, "id"> => ({
  name: "",
  gradeLevel: GradeLevel.Alef,
  capacity: 20,
  supportedDisabilities: [],
});

export const ClassroomsPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const { items, loading } = useAppSelector((s) => s.classrooms);
  const [form, setForm] = useState(emptyForm());
  const [editId, setEditId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => { dispatch(fetchClassrooms()); }, [dispatch]);

  const toggleDisability = (d: DisabilityType) => {
    setForm((f) => ({
      ...f,
      supportedDisabilities: f.supportedDisabilities.includes(d)
        ? f.supportedDisabilities.filter((x) => x !== d)
        : [...f.supportedDisabilities, d],
    }));
  };

  const handleSave = () => {
    if (!form.name) return;
    if (editId !== null) {
      dispatch(updateClassroom({ id: editId, dto: form }));
    } else {
      dispatch(createClassroom(form));
    }
    setForm(emptyForm());
    setEditId(null);
    setShowForm(false);
  };

  const handleEdit = (c: Classroom) => {
    setForm({ name: c.name, gradeLevel: c.gradeLevel, capacity: c.capacity, supportedDisabilities: c.supportedDisabilities });
    setEditId(c.id);
    setShowForm(true);
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1>ניהול כיתות</h1>
        <button className="btn btn-primary" onClick={() => { setForm(emptyForm()); setEditId(null); setShowForm(true); }}>
          + כיתה חדשה
        </button>
      </div>

      {showForm && (
        <div className="card form-card">
          <h2>{editId ? "עריכת כיתה" : "הוספת כיתה"}</h2>
          <div className="form-row">
            <label>שם הכיתה</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="לדוגמה: א׳1" />
          </div>
          <div className="form-row">
            <label>שכבה</label>
            <select value={form.gradeLevel} onChange={(e) => setForm({ ...form, gradeLevel: Number(e.target.value) as GradeLevel })}>
              {ALL_GRADES.map((g) => (
                <option key={g} value={g}>{GRADE_LABELS[g]}</option>
              ))}
            </select>
          </div>
          <div className="form-row">
            <label>קיבולת</label>
            <input type="number" min={1} max={40} value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} />
          </div>
          <div className="form-row">
            <label>נכויות נתמכות</label>
            <div className="checkbox-group">
              {ALL_DISABILITIES.map((d) => (
                <label key={d} className="checkbox-label">
                  <input type="checkbox" checked={form.supportedDisabilities.includes(d)} onChange={() => toggleDisability(d)} />
                  {DISABILITY_LABELS[d]}
                </label>
              ))}
            </div>
          </div>
          <div className="form-actions">
            <button className="btn btn-primary" onClick={handleSave}>שמור</button>
            <button className="btn" onClick={() => { setShowForm(false); setEditId(null); }}>ביטול</button>
          </div>
        </div>
      )}

      {loading && <p>טוען...</p>}

      <div className="cards-grid">
        {items.map((c) => (
          <div className="card classroom-card" key={c.id}>
            <div className="card-title">{c.name}</div>
            <div className="card-meta">שכבה {GRADE_LABELS[c.gradeLevel]} · {c.capacity} מקומות</div>
            <div className="tags">
              {c.supportedDisabilities.length === 0
                ? <span className="tag tag-none">ללא התאמות</span>
                : c.supportedDisabilities.map((d) => (
                  <span key={d} className="tag">{DISABILITY_LABELS[d]}</span>
                ))}
            </div>
            <div className="card-actions">
              <button className="btn btn-sm" onClick={() => handleEdit(c)}>עריכה</button>
              <button className="btn btn-sm btn-danger" onClick={() => dispatch(deleteClassroom(c.id))}>מחיקה</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
