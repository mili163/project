import React, { useRef, useState } from "react";
import { useAppDispatch, useAppSelector } from "../store";
import { importStudents, clearStudents } from "../store/studentsSlice";
import { DISABILITY_LABELS, GRADE_LABELS } from "../types";

export const ImportPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const { items, loading, error } = useAppSelector((s) => s.students);
  const fileRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>("");

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    dispatch(importStudents(file));
  };

  return (
    <div className="page">
      <h1>ייבוא תלמידים</h1>
      <p className="hint">
        העלה קובץ CSV עם עמודות: <code>FirstName, LastName, GradeLevel, Disabilities</code>
        <br />
        <small>Disabilities = רשימה מופרדת בפסיקים: Blind, Deaf, Physical, Cognitive, Speech</small>
      </p>

      <div className="upload-area">
        <input
          ref={fileRef}
          type="file"
          accept=".csv"
          onChange={handleFile}
          style={{ display: "none" }}
          id="csv-input"
        />
        <label htmlFor="csv-input" className="btn btn-primary">
          {loading ? "טוען..." : "בחר קובץ CSV"}
        </label>
        {fileName && <span className="file-name">{fileName}</span>}
        {items.length > 0 && (
          <button className="btn btn-danger" onClick={() => dispatch(clearStudents())}>
            נקה הכל
          </button>
        )}
      </div>

      {error && <div className="error">{error}</div>}

      {items.length > 0 && (
        <table className="data-table">
          <thead>
            <tr>
              <th>שם פרטי</th>
              <th>שם משפחה</th>
              <th>שכבה</th>
              <th>נכויות</th>
            </tr>
          </thead>
          <tbody>
            {items.map((s) => (
              <tr key={s.id}>
                <td>{s.firstName}</td>
                <td>{s.lastName}</td>
                <td>{GRADE_LABELS[s.gradeLevel]}</td>
                <td>
                  {s.disabilities.length === 0
                    ? "—"
                    : s.disabilities.map((d) => DISABILITY_LABELS[d]).join(", ")}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};
