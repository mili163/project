import React from "react";
import { useAppDispatch, useAppSelector } from "../store";
import { runSort, clearSort } from "../store/sortSlice";
import { DISABILITY_LABELS, GRADE_LABELS } from "../types";

export const SortPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const { result, loading, error } = useAppSelector((s) => s.sort);
  const studentCount = useAppSelector((s) => s.students.items.length);
  const classroomCount = useAppSelector((s) => s.classrooms.items.length);

  return (
    <div className="page">
      <div className="page-header">
        <h1>מיון תלמידים לכיתות</h1>
        <div className="sort-meta">
          <span>{studentCount} תלמידים</span>
          <span>{classroomCount} כיתות</span>
        </div>
      </div>

      <div className="sort-actions">
        <button
          className="btn btn-primary btn-large"
          onClick={() => dispatch(runSort())}
          disabled={loading || studentCount === 0 || classroomCount === 0}
        >
          {loading ? "ממיין..." : "הפעל מיון"}
        </button>
        {result && (
          <button className="btn" onClick={() => dispatch(clearSort())}>נקה תוצאות</button>
        )}
      </div>

      {error && <div className="error">{error}</div>}

      {result && (
        <>
          <div className="summary-banner">
            <span className="summary-ok">✓ {result.assignments.length} תלמידים שובצו</span>
            {result.unassigned.length > 0 && (
              <span className="summary-warn">⚠ {result.unassigned.length} תלמידים לא שובצו</span>
            )}
          </div>

          <h2>טבלת שיבוצים</h2>
          <table className="data-table">
            <thead>
              <tr>
                <th>שם התלמיד</th>
                <th>שכבה</th>
                <th>נכויות</th>
                <th>כיתה</th>
                <th>שם כיתה</th>
              </tr>
            </thead>
            <tbody>
              {result.assignments.map((a, i) => (
                <tr key={i}>
                  <td>{a.student.firstName} {a.student.lastName}</td>
                  <td>{GRADE_LABELS[a.student.gradeLevel]}</td>
                  <td>
                    {a.student.disabilities.length === 0
                      ? "—"
                      : a.student.disabilities.map((d) => DISABILITY_LABELS[d]).join(", ")}
                  </td>
                  <td>{GRADE_LABELS[a.classroom.gradeLevel]}</td>
                  <td>{a.classroom.name}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {result.unassigned.length > 0 && (
            <>
              <h2 className="warn-title">תלמידים ללא שיבוץ</h2>
              <table className="data-table warn-table">
                <thead>
                  <tr>
                    <th>שם</th>
                    <th>שכבה</th>
                    <th>נכויות</th>
                    <th>סיבה</th>
                  </tr>
                </thead>
                <tbody>
                  {result.unassigned.map((s) => (
                    <tr key={s.id}>
                      <td>{s.firstName} {s.lastName}</td>
                      <td>{GRADE_LABELS[s.gradeLevel]}</td>
                      <td>{s.disabilities.map((d) => DISABILITY_LABELS[d]).join(", ") || "—"}</td>
                      <td>אין כיתה מתאימה / אין מקום</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </>
      )}
    </div>
  );
};
