export enum DisabilityType {
  None = "None",
  Blind = "Blind",
  Deaf = "Deaf",
  Physical = "Physical",
  Cognitive = "Cognitive",
  Speech = "Speech",
}

export enum GradeLevel {
  Alef = 1,
  Bet = 2,
  Gimel = 3,
  Dalet = 4,
  He = 5,
  Vav = 6,
}

export const GRADE_LABELS: Record<GradeLevel, string> = {
  [GradeLevel.Alef]: "א׳",
  [GradeLevel.Bet]: "ב׳",
  [GradeLevel.Gimel]: "ג׳",
  [GradeLevel.Dalet]: "ד׳",
  [GradeLevel.He]: "ה׳",
  [GradeLevel.Vav]: "ו׳",
};

export const DISABILITY_LABELS: Record<DisabilityType, string> = {
  [DisabilityType.None]: "ללא",
  [DisabilityType.Blind]: "עיוורון",
  [DisabilityType.Deaf]: "חרשות",
  [DisabilityType.Physical]: "נכות פיזית",
  [DisabilityType.Cognitive]: "לקות קוגניטיבית",
  [DisabilityType.Speech]: "לקות דיבור",
};

export interface Student {
  id: number;
  firstName: string;
  lastName: string;
  gradeLevel: GradeLevel;
  disabilities: DisabilityType[];
}

export interface Classroom {
  id: number;
  name: string;
  gradeLevel: GradeLevel;
  capacity: number;
  supportedDisabilities: DisabilityType[];
}

export interface Assignment {
  student: Student;
  classroom: Classroom;
}

export interface SortResult {
  assignments: Assignment[];
  unassigned: Student[];
}
