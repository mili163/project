import { Classroom, SortResult, Student } from "../types";

const BASE = "http://localhost:5000/api";

export const api = {
  // Students
  getStudents: (): Promise<Student[]> =>
    fetch(`${BASE}/students`).then((r) => r.json()),

  importStudents: (file: File): Promise<Student[]> => {
    const form = new FormData();
    form.append("file", file);
    return fetch(`${BASE}/students/import`, { method: "POST", body: form }).then(
      (r) => r.json()
    );
  },

  clearStudents: (): Promise<void> =>
    fetch(`${BASE}/students`, { method: "DELETE" }).then(() => undefined),

  // Classrooms
  getClassrooms: (): Promise<Classroom[]> =>
    fetch(`${BASE}/classrooms`).then((r) => r.json()),

  createClassroom: (
    dto: Omit<Classroom, "id">
  ): Promise<Classroom> =>
    fetch(`${BASE}/classrooms`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dto),
    }).then((r) => r.json()),

  updateClassroom: (
    id: number,
    dto: Omit<Classroom, "id">
  ): Promise<Classroom> =>
    fetch(`${BASE}/classrooms/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dto),
    }).then((r) => r.json()),

  deleteClassroom: (id: number): Promise<void> =>
    fetch(`${BASE}/classrooms/${id}`, { method: "DELETE" }).then(
      () => undefined
    ),

  // Sort
  runSort: (): Promise<SortResult> =>
    fetch(`${BASE}/sort`, { method: "POST" }).then((r) => r.json()),

  getLastSort: (): Promise<SortResult> =>
    fetch(`${BASE}/sort`).then((r) => r.json()),
};
