using Microsoft.AspNetCore.Mvc;
using StudentSorter.Models;
using StudentSorter.Services;

namespace StudentSorter.Controllers;

[ApiController]
[Route("api/[controller]")]
public class StudentsController : ControllerBase
{
    private readonly ICsvParserService _csvParser;
    private readonly IDataStore _store;

    public StudentsController(ICsvParserService csvParser, IDataStore store)
    {
        _csvParser = csvParser;
        _store = store;
    }

    // GET /api/students
    [HttpGet]
    public ActionResult<List<Student>> GetAll() => Ok(_store.Students);

    // POST /api/students/import  (multipart/form-data, field: file)
    [HttpPost("import")]
    public async Task<ActionResult<List<Student>>> Import(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        await using var stream = file.OpenReadStream();
        var imported = _csvParser.ParseStudents(stream);

        _store.Students.Clear();
        _store.Students.AddRange(imported);

        return Ok(_store.Students);
    }

    // DELETE /api/students
    [HttpDelete]
    public IActionResult Clear()
    {
        _store.Students.Clear();
        return NoContent();
    }
}
