using Microsoft.AspNetCore.Mvc;
using StudentSorter.Models;
using StudentSorter.Services;

namespace StudentSorter.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SortController : ControllerBase
{
    private readonly ISortingService _sorter;
    private readonly IDataStore _store;

    public SortController(ISortingService sorter, IDataStore store)
    {
        _sorter = sorter;
        _store = store;
    }

    // POST /api/sort  — runs sorting algorithm on current students & classrooms
    [HttpPost]
    public ActionResult<SortResult> Run()
    {
        if (!_store.Students.Any())
            return BadRequest("No students imported.");
        if (!_store.Classrooms.Any())
            return BadRequest("No classrooms defined.");

        var result = _sorter.Sort(_store.Students, _store.Classrooms);
        _store.LastSortResult = result;
        return Ok(result);
    }

    // GET /api/sort  — fetch last result
    [HttpGet]
    public ActionResult<SortResult> GetLast()
    {
        if (_store.LastSortResult == null)
            return NotFound("No sort has been run yet.");
        return Ok(_store.LastSortResult);
    }
}
