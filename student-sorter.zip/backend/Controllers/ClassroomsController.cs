using Microsoft.AspNetCore.Mvc;
using StudentSorter.Models;
using StudentSorter.Services;

namespace StudentSorter.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ClassroomsController : ControllerBase
{
    private readonly IDataStore _store;
    private static int _nextId = 1;

    public ClassroomsController(IDataStore store) => _store = store;

    // GET /api/classrooms
    [HttpGet]
    public ActionResult<List<Classroom>> GetAll() => Ok(_store.Classrooms);

    // POST /api/classrooms
    [HttpPost]
    public ActionResult<Classroom> Create([FromBody] CreateClassroomDto dto)
    {
        var classroom = new Classroom
        {
            Id = _nextId++,
            Name = dto.Name,
            GradeLevel = dto.GradeLevel,
            Capacity = dto.Capacity,
            SupportedDisabilities = dto.SupportedDisabilities
        };
        _store.Classrooms.Add(classroom);
        return CreatedAtAction(nameof(GetAll), classroom);
    }

    // PUT /api/classrooms/{id}
    [HttpPut("{id}")]
    public ActionResult<Classroom> Update(int id, [FromBody] CreateClassroomDto dto)
    {
        var existing = _store.Classrooms.FirstOrDefault(c => c.Id == id);
        if (existing == null) return NotFound();

        existing.Name = dto.Name;
        existing.GradeLevel = dto.GradeLevel;
        existing.Capacity = dto.Capacity;
        existing.SupportedDisabilities = dto.SupportedDisabilities;
        return Ok(existing);
    }

    // DELETE /api/classrooms/{id}
    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var existing = _store.Classrooms.FirstOrDefault(c => c.Id == id);
        if (existing == null) return NotFound();
        _store.Classrooms.Remove(existing);
        return NoContent();
    }
}

public class CreateClassroomDto
{
    public string Name { get; set; } = "";
    public GradeLevel GradeLevel { get; set; }
    public int Capacity { get; set; }
    public List<DisabilityType> SupportedDisabilities { get; set; } = new();
}
