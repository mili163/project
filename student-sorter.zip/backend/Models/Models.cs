namespace StudentSorter.Models;

public enum DisabilityType
{
    None,
    Blind,
    Deaf,
    Physical,
    Cognitive,
    Speech
}

public enum GradeLevel
{
    Alef = 1,
    Bet = 2,
    Gimel = 3,
    Dalet = 4,
    He = 5,
    Vav = 6
}

public class Student
{
    public int Id { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public GradeLevel GradeLevel { get; set; }
    public List<DisabilityType> Disabilities { get; set; } = new();
}

public class Classroom
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public GradeLevel GradeLevel { get; set; }
    public int Capacity { get; set; }
    public List<DisabilityType> SupportedDisabilities { get; set; } = new();
}

public class Assignment
{
    public Student Student { get; set; } = null!;
    public Classroom Classroom { get; set; } = null!;
}

public class SortResult
{
    public List<Assignment> Assignments { get; set; } = new();
    public List<Student> Unassigned { get; set; } = new();
}
