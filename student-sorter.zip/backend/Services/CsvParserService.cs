using StudentSorter.Models;
using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;

namespace StudentSorter.Services;

public class CsvRecord
{
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public int GradeLevel { get; set; }
    // Comma-separated disability types, e.g. "Blind,Deaf"
    public string Disabilities { get; set; } = "";
}

public interface ICsvParserService
{
    List<Student> ParseStudents(Stream csvStream);
}

public class CsvParserService : ICsvParserService
{
    private static int _nextId = 1;

    public List<Student> ParseStudents(Stream csvStream)
    {
        var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HeaderValidated = null,
            MissingFieldFound = null
        };

        using var reader = new StreamReader(csvStream);
        using var csv = new CsvReader(reader, config);

        var records = csv.GetRecords<CsvRecord>().ToList();
        var students = new List<Student>();

        foreach (var rec in records)
        {
            var disabilities = rec.Disabilities
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(d => Enum.TryParse<DisabilityType>(d, true, out var dt) ? dt : DisabilityType.None)
                .Where(d => d != DisabilityType.None)
                .Distinct()
                .ToList();

            students.Add(new Student
            {
                Id = _nextId++,
                FirstName = rec.FirstName,
                LastName = rec.LastName,
                GradeLevel = (GradeLevel)rec.GradeLevel,
                Disabilities = disabilities
            });
        }

        return students;
    }
}
