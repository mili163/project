using StudentSorter.Models;

namespace StudentSorter.Services;

public interface ISortingService
{
    SortResult Sort(List<Student> students, List<Classroom> classrooms);
}

public class SortingService : ISortingService
{
    /// <summary>
    /// Sorts students into classrooms:
    /// 1. Group students by GradeLevel
    /// 2. For each student find a classroom that:
    ///    a. Matches GradeLevel
    ///    b. Supports ALL of the student's disabilities
    ///    c. Has available capacity
    /// 3. Students with no match go to Unassigned
    /// </summary>
    public SortResult Sort(List<Student> students, List<Classroom> classrooms)
    {
        // Track remaining capacity per classroom
        var capacityMap = classrooms.ToDictionary(c => c.Id, c => c.Capacity);
        // Track which students are already assigned to each classroom
        var assignmentMap = classrooms.ToDictionary(c => c.Id, _ => new List<Student>());

        var assignments = new List<Assignment>();
        var unassigned = new List<Student>();

        // Sort students so those with MORE disabilities are placed first (harder to fit)
        var sortedStudents = students
            .OrderByDescending(s => s.Disabilities.Count)
            .ThenBy(s => s.GradeLevel)
            .ToList();

        foreach (var student in sortedStudents)
        {
            var matchedClassroom = classrooms
                .Where(c =>
                    c.GradeLevel == student.GradeLevel &&
                    capacityMap[c.Id] > 0 &&
                    student.Disabilities.All(d => c.SupportedDisabilities.Contains(d)))
                .OrderBy(c => capacityMap[c.Id]) // fill fuller rooms first (balance load)
                .FirstOrDefault();

            if (matchedClassroom != null)
            {
                capacityMap[matchedClassroom.Id]--;
                assignmentMap[matchedClassroom.Id].Add(student);
                assignments.Add(new Assignment
                {
                    Student = student,
                    Classroom = matchedClassroom
                });
            }
            else
            {
                unassigned.Add(student);
            }
        }

        return new SortResult
        {
            Assignments = assignments,
            Unassigned = unassigned
        };
    }
}
