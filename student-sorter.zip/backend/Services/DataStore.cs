using StudentSorter.Models;

namespace StudentSorter.Services;

/// <summary>
/// Simple in-memory store — swap with EF Core / DB context when needed
/// </summary>
public interface IDataStore
{
    List<Student> Students { get; }
    List<Classroom> Classrooms { get; }
    SortResult? LastSortResult { get; set; }
}

public class InMemoryDataStore : IDataStore
{
    public List<Student> Students { get; } = new();
    public List<Classroom> Classrooms { get; } = new();
    public SortResult? LastSortResult { get; set; }
}
